package com.capgemini.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.repository.EmployeeRepository;
import com.capgemini.service.EmployeeService;

@Service
@Transactional(readOnly = true)
public class EmployeeServiceImpl implements EmployeeService {

	 @Autowired(required = true)
	 private EmployeeRepository employeeRepository;

	public void createEmployee(String name, String surname, String pesel, Date dateOfBirth) {
		 employeeRepository.insertEmployee(name, surname, pesel, dateOfBirth);
	}

	public void updateEmployee(String name, String surname, String pesel, Date dateOfBirth, int id) {
		employeeRepository.updateEmployeeData(name, surname, pesel, dateOfBirth, id);
	}

}
