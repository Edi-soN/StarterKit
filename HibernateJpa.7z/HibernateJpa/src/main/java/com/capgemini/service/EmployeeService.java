package com.capgemini.service;

import java.util.Date;

public interface EmployeeService {

	public void createEmployee(String name, String surname, String pesel, Date dateOfBirth);

	public void updateEmployee(String name, String surname, String pesel, Date dateOfBirth, int id);

}
