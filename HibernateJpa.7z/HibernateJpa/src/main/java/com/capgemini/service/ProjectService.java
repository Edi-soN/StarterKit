package com.capgemini.service;

import com.capgemini.model.Project;

public class ProjectService {
	
	public Project createProject(){
		return null;
	}
	
	public Project addEmployeeToProject(){
		return null;
	}
	
	public Project removeEmployeeFromProject(){
		return null;
	}
	
}
