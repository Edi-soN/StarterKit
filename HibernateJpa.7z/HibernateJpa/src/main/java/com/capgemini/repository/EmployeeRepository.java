package com.capgemini.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.capgemini.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	@Modifying(clearAutomatically = true)
	@Query(value = "insert into Employee (name, surname, pesel, dateOfBirth) VALUES (?1, ?2, ?3, ?4)")
	  void insertEmployee(String name, String surname, String pesel, Date dateOfBirth);
	
	@Modifying(clearAutomatically = true)
	@Query("update Employee e set e.name = :name, e.surname = :surname, e.pesel = :pesel, e.dateOfBirth = :dateOfBirth where e.id = :id")
	void updateEmployeeData(@Param("name") String name, @Param("surname") String surname,
			@Param("pesel") String pesel, @Param("dateOfBirth") Date dateOfBirth, @Param("id") int id);
	
}
