package com.capgemini.repository;

public interface ProjectRepository {

}
